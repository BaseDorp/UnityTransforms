﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnGO : MonoBehaviour {

    public GameObject Pacman;

	// Use this for initialization
	void Start () {
        Instantiate(Pacman);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
