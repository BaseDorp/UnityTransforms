﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestTransform : MonoBehaviour {

    Vector3 pos;
    Vector3 rot;

    public float rotationSpeed = 1f;
    public float speed = 0.1f;

	// Use this for initialization
	void Start ()
    {

        // Stores the x,y,z values
        pos = transform.position;
	}
	
	// Update is called once per frame
	void Update ()
    {
        //ChangePosistion();
        //ChangeTranslate();
        //ChangeScale();
        ChangeRotation();
        
	}

    void ChangePosistion()
    {
        // Changes the x posistion of the object by 0.1 every tick
        pos.x += 0.1f;
        // Set the new position as the transform of the object
        transform.position = pos;
    }

    void ChangeTranslate()
    {
        transform.Translate(speed * Time.deltaTime, 0, 0);
    }

    void ChangeRotation()
    {
        transform.Rotate(0, 0, -rotationSpeed);
    }

    void ChangeScale()
    {
        rot = transform.localScale;
        rot.x += 1f;
        transform.localScale = rot;
    }
}
